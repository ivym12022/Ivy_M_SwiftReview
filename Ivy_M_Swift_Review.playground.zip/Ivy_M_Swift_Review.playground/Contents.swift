/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var celebrity = "Michael Jackson"
print (celebrity)
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
var name = "Ivy"
print (name)
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let language = "Swift"
let constantA = "9"
print(constantA)
let constantB = "25"
print(constantB)
let constantC = "17"
print(constantC)
let constantD = "0.9"
print(constantD)
let constantE = "0.25"
print(constantE)
let constantF = "0.17"
print(constantF)
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/

/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
var Num1 = 9
var Num2 = 25
var Num3 = 17
var Num4 = 0.9
var Num5 = 0.25
var Num6 = 0.17

var add = Int(Num4) + Int(Num5) + Int(Num6) + Num3
print("\(Num4) + \(Num5) + \(Num6) + \(Num3) = \(add)")

var subtract = Num2 - Num3
print("\(Num2) - \(Num3) = \(subtract)")

var divide = Num3 / Num1
print("\(Num3) / \(Num1) = \(divide) ")

var multiply = Num2 * Num3
print("\(Num2) * \(Num3) = \(multiply)")
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature >= 90 {
    print("It's hot wear some shorts!")
} else {
    print("It's cold outside wear some jeans")
}
if raining {
    print("it's pouring outside. you'll need an umbrella today")
} else {
    print("No umbrella today. The weather is fine")
}
if time == "Morning" {
    print ("It's time for school")
} else {
    print("It's time for bed")
}

/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for index in (1...10){
    print(index)
}
var index = 10
while (index >= 1 ) {
    print(index)
    index-=1
}

/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var abcs: [String] = ["A is for apple","B is for banana","C is for carrot","D is for donut","E is for eggnog"]
var abcsDrinks: [String] = ["F is for frappuccino","G is for gatorade"]

for item in abcs {
    print(item)
}
for item in abcsDrinks {
    print(item)
}
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiply(Num4: Int, Num5: Int) -> Int{
    return Num4 * Num5
}
print(multiply(Num4: Int(0.9), Num5: Int(0.25)))

/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var Sub = {(Num1: Int, Num2: Int) -> Int in
    return Num1 - Num2
}
let difference = Sub(100,50)
print(difference)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
import UIKit

enum FirstName {
    case Ivy
    case Elliot
    case Alexis
}
var displayBirthday = FirstName.Ivy

switch displayBirthday {

case .Ivy:
    print ("September 25th")
case .Elliot:
    print ("October 11th")
case .Alexis:
    print ("October 30th")
}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct Name {
    var firstName : String
    var middleName: String
    var lastName : String
}
var nameStructure = Name (firstName:"Ivy", middleName: "Marie", lastName: "Mitchell" )
print(nameStructure.firstName)
print(nameStructure.middleName)
print(nameStructure.lastName)
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
class coffee {
    var size: String = "small"
    var caffnated: Bool = true
    var cream: Bool = true
    var sugar: Bool = true
    
    func order (){
        print("your order is ready!")
    }
}
var drink: coffee
